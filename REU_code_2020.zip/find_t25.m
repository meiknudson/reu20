%{
use - find actual value of rejection time given graft population over time

if the graft survives longer than the t(end), then t25 = 999
to be sure that t25=999 iff the graft survives, make sure Graft is carried
out to steady state

%}

function t25 = find_t25(t, Graft, y25)

[~,unique_Graft_indices,~] = unique(Graft);


t25 = interp1(Graft(unique_Graft_indices),t(unique_Graft_indices),y25);
    if isnan(t25) == 1
        t25 = 999;
        %warning('value with no destruction\n') 
    end

end
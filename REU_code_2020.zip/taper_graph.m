%% Taper graph
% shows length of taper (days) vs. time until rejection 

Q = 200; 
taper = [1:100]; %number of days of taper
dose = 100; %CNI dose size
dosenum = 1; %single dose
CNIstart = 0; %give CNI on day 0
taperstart = 1; %start tapering on day 1

for i = 1:length(taper)
    [t,x] = solveODE_expATv2_IStaper(Q,'CNI',[dose,dosenum,CNIstart],...
        'taper',[taperstart,taper(i)]);
    rejtime = find_t25(t,x(:,14),y25);
    yvals(i) = rejtime;
    xvals(i) = taper(i);
end

plot(xvals,yvals,'linewidth',2)
hold on
xlabel('Taper length (days)')
ylabel('Time until graft rejection (days)')

%% IS figures 
figure(1)
% set percent reduction = 0.5
% AT
[t,x]=solveODE_expATv2_IStaper(200,'AT',[1e6,1,1,0,0,1]);
plot(t,x(:,13),'b','linewidth',2)
hold on
graft=x(:,14);
t25=find_t25(t,graft,y25) 

% AT + IS
[t,x]=solveODE_expATv2_IStaper(200,'AT',[1e6,1,1,0,0,1],'CNI',[100,1,0]);
plot(t,x(:,13),'r','linewidth',2)
graft=x(:,14);
t25=find_t25(t,graft,y25)

% IS sub
[t,x]=solveODE_expATv2_IStaper(200,'CNI',[100,1,0]);
plot(t,x(:,13),'m','linewidth',2)
graft=x(:,14);
t25=find_t25(t,graft,y25)



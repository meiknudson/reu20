%{
calls:
    LN_Graft_IS - system of ODEs, modified by opts
    allParams - initial conditions

Inputs:
    Q - number of days in trial

    varargin (in this order)
        1) if parameters are being changed cell containing changes must be
        first varargin, can change multiple parameters
            e.g. {'psiIS_mTOR', 1e15}
        2) string(s) of the output(s) desired, can be any of the
        populations tracked by the ODEs  (e.g. 'Graft', 'EffNaive', etc.)
        3) treatment required followed directly by the options for that treatment
            (a) 'AT', [dose, number of doses, graft, LN active, LN naive, start day]
            (b) 'CNI', [dose, number of doses, start day]
                    (if dosing function is bolus use above. if constant
                    dose only include dose and no other values)
                    For subtherapeutic dosing, make sure params.percent_reduction
                    is set to 0.5; if therapeutic, use 0.99
            (c) 'mTOR', (see (b) for option format)
            (d) 'taper', [start day, length]

        ex. solveODE_expATv2_IStaper(200,'CNI',[100,1,0],'taper',[1,10])
        ex. sovleODE_expATv2_IStaper(200,'AT',[1e6,1,1,0,0,0])

Outputs:
    t - time vector
    x - all of the populations
    varargout - whichever of the populations specified by varargin (see #2)
%}

function [t, x] = solveODE_expATv2_IStaper(Q, varargin)
options = odeset('RelTol', 1e-4, 'NonNegative', [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17]);

[params]=allParamsv2;


% Treatments
treatments = [0,0,0,0];
ATopts = 0;
ISopts = 0;
taperOpts = 0;


% see what treatments are being used and apply options
if ~isempty(varargin)
    
    
    for i = 1: numel(varargin)
        
        % if AT is chosen, then assign user inputs
        if strcmp(varargin{i},'AT')
            treatments(1) = 1;
            ATopts = varargin{i + 1};
        end
        
        % check if/which IS treatment
        if strcmp(varargin{i},'CNI')
            treatments(2)=1;
%                         if strcmp(varargin{i+1},'b') %bolus dose
%                             treatments(2) = 1;
%                         elseif strcmp(varargin{i+1},'c') %constant dose
%                             treatments(2) = 2;
%                         elseif strcmp(varargin{i+1},'t') %tapered dose
%                             treatments(2) = 3;
%                         end
            
            ISopts = varargin{i + 1};
%             iniIS = ISopts(1); % set initial magnitude IS
%             iniConditions(17) = iniIS;
            
        elseif strcmp(varargin{i},'mTOR')
            treatments(3) = 1;                    
            ISopts = varargin{i + 1};
            iniIS = ISopts(1); % set initial magnitude IS
            iniConditions(17) = iniIS;
            
        end
        
        if strcmp(varargin{i},'taper')
            treatments(4) = 1;
            taperOpts = varargin{i + 1};
            startTaper = taperOpts(1);
            lenTaper = taperOpts(2);
        end
        
    end
end


if treatments(1)
    %D0_exp = actual_dose(ATopts(1));  %determine correct amplitude based on old dosing function
    %ATopts(1) = D0_exp;  %re-set dose amplitude accordingly
end

treatOpts = {treatments, ATopts, ISopts, taperOpts};

%This gives the case of no treatment
if ~treatments(1) && ~treatments(2) && ~treatments(3) && ~treatments(4)
    [t,x] = ode45(@(t,x) IS_taper(t,x,params, treatOpts), [0 Q], params.iniConditions);
end


%This assumes some type of IS treatment
if (treatments(2) && ~treatments(4)) || treatments(1)  %CNI with no taper or AT
    [t,x] = ode45(@(t,x) IS_taper(t,x,params, treatOpts), [0 Q], params.iniConditions, options);
else  %CNI with taper
    [t1,x1] = ode45(@(t,x) IS_taper(t,x,params, treatOpts), [0 startTaper], params.iniConditions, options);
        xvector1 = x1(end,:);
    [t2,x2] = ode45(@(t,x) IS_taper(t,x,params, treatOpts), [startTaper startTaper+lenTaper], xvector1, options);
        xvector2 = x2(end,:);
    [t3,x3] = ode45(@(t,x) IS_taper(t,x,params, treatOpts), [startTaper+lenTaper Q], xvector2, options);    
    t = [t1;t2;t3];
    x = [x1;x2;x3]; 
end 

% 
% %If there is AT, enter this if statement
% if treatments(1)
%     
%     doseLength = ATopts(2); %number of doses
%     startDay = ATopts(6);
% 
%     
%     endDay = startDay + doseLength - 1;
%     doseTime = startDay:endDay;
%     
%     if doseLength >1  %Multiple doses
%         if startDay ~=0
%             
%             [t1,x1] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [0 startDay], params.iniConditions);
%             params.iniConditions = x1(end,:);
%             t = t1;
%             x = x1;
%             
%             for i = 1:length(doseTime) - 1
%                 [t1,x1] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [doseTime(i) doseTime(i+1)], params.iniConditions);
%                 params.iniConditions = x1(end,:);
%                 
%                 t = [t;t1];
%                 x = [x;x1];
%             end
%             
%             [t1,x1] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [endDay Q], params.iniConditions);
%             t = [t;t1];
%             x = [x;x1];
%         end
%         
%         if startDay ==0
% 
%             for i = 1:length(doseTime) - 1
%                 [t1,x1] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [doseTime(i) doseTime(i+1)], params.iniConditions);
%                 params.iniConditions = x1(end,:);
%                 if i == 1
%                     t = t1;
%                     x = x1;
%                 else
%                     t = [t;t1];
%                     x = [x;x1];
%                 end
%             end
%             
%             [t1,x1] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [endDay Q], params.iniConditions);
%             t = [t;t1];
%             x = [x;x1];
%         end
%     else  % Single dose
%         [t,x] = ode45(@(t,x) LN_Graft_expATv2(t,x,params, treatOpts), [0 Q], params.iniConditions);
%     end
%     
%     %     if ~isempty(varargin)
%     %         xvector = x(end,:);
%     %         ALN = x(:,1);
%     %         EffNaive = x(:,2);
%     %         EffLN = x(:,3);
%     %         RegNaive = x(:,4);
%     %         RegLN = x(:,5);
%     %         HelpNaive = x(:,6);
%     %         HelpLN = x(:,7);
%     %         AG = x(:,8);
%     %         AnaiveG = x(:,9);
%     %         InflammAPCG = x(:,10);
%     %         EffG = x(:,11);
%     %         RegG = x(:,12);
%     %         HelpG = x(:,13);
%     %         Graft = x(:,14);
%     %         Cp = x(:,15);
%     %         Ca = x(:,16);
%     %         IS = x(:,17);
%     %
%     %         names = {'xvector', 'ALN', 'EffNaive', 'EffLN', 'RegNaive', ...
%     %             'RegLN', 'HelpNaive', 'HelpLN', 'AG', 'AnaiveG', ...
%     %             'InflammAPCG', 'EffG', 'RegG', 'HelpG', 'Graft', 'Cp', 'Ca', 'IS'};
%     %
%     %         vars = {xvector, ALN, EffNaive, EffLN, RegNaive, ...
%     %             RegLN, HelpNaive, HelpLN, AG, AnaiveG, ...
%     %             InflammAPCG, EffG, RegG, HelpG, Graft, Cp, Ca,IS};
%     %
%     %         % initialize o to make sure outputs go to correct variable
%     %         o = 1;
%     %
%     %         for i = 1: numel(varargin)
%     %             for j = 1:length(names)
%     %                 if strcmp(varargin{i},names{j})
%     %                     varargout{o} = vars{j};
%     %                     o = o + 1;
%     %                     break
%     %                 end
%     %             end
%     %         end
%     %
%     %     end
% end
% % 
% figure(1)
% hold on
% plot(t,x(:,14),'g','linewidth',2)
% plot([t(1) t(end)],[params.Graft_ini/4 params.Graft_ini/4],'k--')
% xlabel('time')
% ylabel('Graft')

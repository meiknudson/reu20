%{
when changing cell popualtions note that 
1 = APC in LN
2 = Naive Effector T cells LN 
3 = Effector T cells LN
4 = Naive regulator T cells LN
5 = Regulatory T cells LN
6 = Naive helper T cells LN
7 = Helper T cells LN
8 = APC mature Graft
9 = APC Immature Graft
10 = APC inflammatory Graft
11 = Effector T cells Graft
12 = Regulatory T cells Graft
13 = Helper T cells Graft
14 = Graft cells
15 = Pro-inflammatory Cytokines Graft
16 = Anti-inflammatory Cytokines Graft
%}
%% Single vs Multiple Population Graphs
% use to plot different cell populations for single vs multiple doses
clear
[params]=allParamsv2; %calls parameters 
Q = 200;  % number of days in trial
t_star=0; % day of administration 
dose_val=1e6; % dose size of single dose (cells/day)
dose_freq=1;  % single dose
dose_freqmult=13; %number of multiple doses
dose_valmult=1e6/dose_freqmult; %dose size per day for multiple dose

%AT single dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val,dose_freq,1,0,0,t_star]);
plot(t,x(:,14),'b','linewidth',2); %change x value to plot different cell populations  
hold on

%AT mult doses
[t,x]=solveODE_expATv2(Q,'AT',[dose_valmult,dose_freqmult,1,0,0,t_star]);
plot(t,x(:,14),'r','linewidth',2); %change x value to plot different cell populations

xlabel('Time (days)')
ylabel('Graft (cells)')
plot([t(1) t(end)],[params.y25 params.y25],'k --','Linewidth',1) %line showing when rejection occurs - commment out when not plotting graft  
legend({'single dose','mult doses'},'location','northeast');

%% Effects of timing and dosage
%use to plot cell populations for different dosing times/magnitudes
clear
[params]=allParamsv2; %calls parameter
Q = 200; %number of days in trial
t_star1 = 0; %day 0 administration
t_star2 = 2; %day 2 administration
dose_val1 = 1e6; %low dose
dose_val2 = 5e6; %high dose
dose_freq = 1; %single dose
y25=params.Graft_ini/4; % 25 percent of graft size (size of rejection)

% Day 0 with 1e6 dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val1,dose_freq,1,0,0,t_star1]);
plot(t,x(:,14),'linewidth',2); %change for different cell populations
xlim([0 50])
graft=x(:,14); %use this code to find day of rejection
t25a=find_t25(t,graft,y25); 
hold on

% Day 0 with 5e6 dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val2,dose_freq,1,0,0,t_star1]);
plot(t,x(:,14),'linewidth',2);  %change for different cell populations
graft=x(:,14); %use this code to find day of rejection
t25b=find_t25(t,graft,y25);

%Day 2 with 1e6 dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val1,dose_freq,1,0,0,t_star2]);
plot(t,x(:,14),'linewidth',2); %change for different cell populations
graft=x(:,14); %use this code to find day of rejection
t25c=find_t25(t,graft,y25);

%Day 2 with 5e6 dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val2,dose_freq,1,0,0,t_star2]);
plot(t,x(:,14),'linewidth',2);  %change for different cell populations
graft=x(:,14); %use this code to find day of rejection
t25d=find_t25(t,graft,y25);

xlabel('Time (days)')
ylabel('Graft Cells') 
plot([t(1) t(end)],[params.y25 params.y25],'k --','Linewidth',1) %line showing when rejection occurs
legend({'Day 0 1e6','Day 0 5e6', 'Day 2 1e6','Day 2 5e6'},'location','northeast');

%% contribution of Effector vs Inflammatory APCs to Graft Equation
clear
[params]=allParamsv2;
Q = 200;
%change following lines to reflect different days/dosing strategies/magnitudes
t_star = 0; %day 0 
dose_val = 1e6; %dosing size
dose_freq = 1; %number of doses


[t,x] = solveODE_expATv2(Q,'AT',[dose_val/dose_freq,dose_freq,1,0,0,t_star]);
Gg= x(:,14); %graft cells
Ainf = x(:,10); %inflammatory APCs
TE = x(:,11); %effector T cells
TR = x(:,12); %regulatory T cells

plot(t,params.dinf.*Ainf.*Gg./(params.alpha7+TR),'linewidth',2); %contribution of inf
xlim([0 50])
hold on 
plot(t,(params.dE.*TE.*Gg./(params.alpha8+TR)),'linewidth',2); %contribution of effectors
plot(t,params.dinf.*Ainf.*Gg./(params.alpha7+TR) + params.dE.*TE.*Gg./(params.alpha8+TR),'linewidth',2); % total contribution

xlabel('Time (Days)');
ylabel('Contributions to the Graft')
legend({'inflammatory', 'effector','total'},'location','northeast');

%% Finding intersection points 
%use to find when graft size of single dose = graft size of multiple dose for various doses
%requires intersections function and takes a long time (~10 min)
clear
[params]=allParamsv2;
Q = 300;
t_star = 0;
dose_freq = [13,50,100,200]; %number of doses explored
D0 = linspace(1e6,5e6,20); %x axis of different dosing values

for i = 1:length(dose_freq) %plot for doses in dose_freq
    for j = 1:length(D0) %outputs for all 20 D0 vals
        %single dose
        [t,x]=solveODE_expATv2(Q,'AT',[D0(j),1,1,0,0,t_star]);
        graft1=x(:,14); %graft size for single dose
        %multiple dose
        [tt,xx]=solveODE_expATv2(Q,'AT',[D0(j)/dose_freq(i),dose_freq(i),1,0,0,t_star]);
        graft2=xx(:,14); %graft size for multiple dose
    	intersect(j)=max(intersections(t,graft1,tt,graft2)); 
    end
    plot(D0,intersect,'linewidth',2);
    hold on
end

xlabel('Dosing Value')
ylabel('Day of intersectiion')
legend({'13 Doses','50 Doses','100 Doses','200 Doses'},'location','northeast')

%% graft survival time for single dose versus a three day consecutive (equivalent) dose
%use to determien 
clear
[params]=allParamsv2;
Q = 200; 
t_star1=0; 
t_star2=0;
dose_val=1e6;
dose_freq=1;
dose_freq3=3;
y25=params.Graft_ini/4; 

%AT on day 0 single dose
[t,x] = solveODE_expATv2(Q,'AT',[dose_val,dose_freq,1,0,0,t_star1]);
figure(10)
plot(t,x(:,14),'linewidth',2); %change for different cell populations
graft=x(:,14);  %use this code to find day of rejection otherwise comment out
t25a=find_t25(t,graft,y25); %use this code to find day of rejection otherwise comment out
hold on

%3 AT doses starting on day 0
[t,x] = solveODE_expATv2(Q,'AT',[dose_val/dose_freq3,dose_freq3,1,0,0,t_star2]);
plot(t,x(:,14),'linewidth',2);
graft=x(:,14); 
t25b=find_t25(t,graft,y25);

xlabel('Time (days)')
ylabel('Graft (cells)')
plot([t(1) t(end)],[params.y25 params.y25],'k --','Linewidth',1); %line showing when rejection occurs - commment out when not plotting graft
legend({'single dose day 0','3 doses starting day 4'},'location','northeast');


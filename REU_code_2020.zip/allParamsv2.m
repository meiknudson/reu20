%{
contains all of the parameters and initial conditions. 
saves in file 'allParams'

contains parameters for IS via CNI (cyclosporin) and mTOR (rapamycin) 

%}
function [params] = allParamsv2

%struct
params = struct; 

params.EffNaive_ini = 55000;
params.RegNaive_ini = 9500;
params.HelpNaive_ini = 70000;


%Initial conditions
params.ALN_ini = 0;
params.EffLN_ini = 0;
params.RegLN_ini = 0;
params.HelpLN_ini = 0;
params.AG_ini = 200; %one tenth of APCimmature
params.AnaiveG_ini = 2000;
params.InflammAPCG_ini = 0;
params.EffG_ini = 0;
params.RegG_ini = 0;
params.HelpG_ini = 0;
params.Graft_ini = 5600000;
params.Cp_ini = 50;
params.Ca_ini = 0;
params.IS_ini = 100;


        
        
        
        
% params.ISini = 0; % assume no treatment
%params.k1 = 0; 


%old optimized parameters--implemented new optimized parameters from Guang
%{
params.ap1  = 1500;
params.kcp = 0.005;
params.muAimm = 60;
params.omega1 = 6300;
params.mucp = 0.15;
params.rho1 = 10.9837;
params.dinf = 0.055;
params.dE = 0.004;
params.aH = 6018.9;
params.aR = 0.00028201;
params.rEg = 0.29955;
params.rRg = 0.0037546;
params.ap2 = 3.844;
params.rho4 = 10.9488;
params.omega2 = 20;
%}


% new parameters from Guang (7/25/18), via optimization

params.ap1 =2432.2497;
params.kcp =0.002731;
params.muAimm =106.8191;
params.omega1 =7579.5553;
params.mucp =0.1843;
params.rho1 =13.9897;
params.dinf =0.05954;
params.dE =0.004305;
params.aH =4858.4511;
params.aR =0.0001870;
params.rEg =0.4710;
params.rRg =0.002003;
params.ap2 =7.6746;
params.rho4 =6.7213;
params.omega2=21.7695;



params.alphavalLN = 2500;
params.alphavalG = 12000; %9500;
params.muA = 1.2; %sourced!
params.muEN = 2e-3; %sourced!
% params.TE0 = params.EffNaive_ini; %sourced!   %DELETE LATER AND REPLACE 
params.aE = 3; %sourced!
params.gamma1 = 100; %sourced!
params.alpha1 = params.alphavalLN;
params.alpha3= params.alphavalLN;
params.rE = 1.51; 
params.beta1 = 5000;
params.muE = 0.7;  %sourced!
params.muHN = 2e-3; %sourced!
params.muRN = 2e-3; %sourced!
% params.TR0 = params.RegNaive_ini; %sourced!  %DELETE LATER AND REPLACE 
params.gamma2 = 1000;
params.rR =0.02; %(1.51 was sourced originally...)
params.alpha2 = 9500;%alphavalLN;
params.muR = 0.7; %sourced! %changed from 0.2 on 12/8/14 -- source gives range of values and 0.7 is max of range
% params.TH0 = params.HelpNaive_ini;
params.muH=0.4; %0.3 sourced!
params.gamma3 =100; %sourced! but should it be 5000?
params.rH=1.51; %sourced!
params.gamma4=4000; %sourced! (but should it be 5000?)

params.eE =.001; %sourced!
params.eR =.001; %sourced!
params.eH =.001; %sourced!
params.eA = 5.5; %sourced!

%Graft

params.alpha4 = params.alphavalG;
params.alpha5 = params.alphavalG;
params.muAmat = params.muA;
params.muAinf = params.muA;
params.zeta = 1e-4; %1e-4;
params.beta2 = 4e6;
params.alpha6 = params.alphavalG;
params.rHg = 0.755;
params.gamma5 = 4000;
params.rG = 0;
params.Gmax = 5600000*1.25;
params.alpha7 = 12000;
params.pi1 = 75;
params.alpha8 = params.alpha7;
params.pi2 = 100;

params.rho2 = 0.024;
params.rho3 = 0.24;
params.alpha9 = params.alphavalG;
params.alpha10 = params.alphavalG;
params.alpha11 = params.alphavalG;
params.alpha12 = params.alphavalG;
params.c1 = 1e-6;
params.c2 = 0.01;
params.c3 = 3;
params.k = 15; 
params.A0 = params.AnaiveG_ini;
params.eta1 = 10; 
params.eta2 = 10;
params.eta3 = 10;
params.eta4 = 10;
params.xi1= 0.000208;
params.xi2= 0.0000063; 
params.xi3= 0.0000000042; 
params.xi4= 0.00025; 
params.muCa=0.05;

params.omega3 = 0.1;
params.omega4 = 0.1;

% new IS params -- all random guesses for now 
%{
options i've tried
psi_mTOR: 
    1e14 approxed to keep alive at 1 mg/kg/day - good for constant dose function 
    1.5e14 approxed to keep alive at 1 mg/kg/day - good for bolus dose 
    %2.8e14; %prolif source 
    %2.3e27; % calc from 30% Tcells/APCs left w/ treatment
psi_LN_CNI: 
    5.2e10 - approxed - good for constant dose funtion 
    5e6 - approxed - good for bolus dose fun
psiG_CNI: 
    4.5e16 - approxed - good for constant dose function
    5e6 - approxed - good for bolus dose fun
%}

params.psiLN_CNI = 2.9e10; 
params.psiG_CNI = 1.1e17;
params.psiLN_mTOR = 1e14;
params.psiG_mTOR = 1e14;
params.muIS_CNI = 1.7; % sourced
params.muIS_mTOR = 0.3; % sourced 
params.hIS_CNI = 0.0007; % found from peak CNI @ 2 hrs
params.hIS_mTOR = 0.004; % found from peak mTOR @ 5 hrs 

params.k1 = 100;
params.k2 = 1;
params.percent_reduction = 0.5; %0.99 if full IS; else 0.5 for sub-therapeutic
params.IS_n = (params.k1/params.k2)/params.percent_reduction-(params.k1/params.k2);

params.y25 = 0.25*params.Graft_ini; 

params.iniConditions = [params.ALN_ini; params.EffNaive_ini; params.EffLN_ini; ...
    params.RegNaive_ini; params.RegLN_ini; params.HelpNaive_ini; params.HelpLN_ini; ...
    params.AG_ini; params.AnaiveG_ini; params.InflammAPCG_ini; params.EffG_ini; ...
    params.RegG_ini; params.HelpG_ini; params.Graft_ini; params.Cp_ini; params.Ca_ini; params.IS_ini]; 


% params.ISparams = [params.psiLN_CNI; params.psiG_CNI; params.psiLN_mTOR; ...
%     params.psiG_mTOR; params.muIS_CNI; params.muIS_mTOR; params.hIS_CNI; ...
%     params.hIS_mTOR]; 


% %Tini
% params.Tini=[params.EffNaive_ini; params.RegNaive_ini; params.HelpNaive_ini;...
%     params.AnaiveG_ini; params.all_params; ...
%     params.alphavalLN; params.alphavalG; params.muA; params.muEN; params.aE;...
%     params.gamma1; params.alpha1; params.alpha3; params.rE; params.beta1; params.muE; ...
%     params.muHN; params.muRN; params.gamma2; params.rR; params.alpha2;...
%     params.muR; params.muH; params.gamma3; params.rH; params.gamma4;...
%     params.eE; params.eR; params.eH; params.eA; ...
%     params.alpha4; params.alpha5; params.muAmat; params.muAinf; params.zeta;...
%     params.beta2; params.alpha6; params.rHg; params.gamma5; params.rG; params.Gmax;...
%     params.alpha7; params.pi1; params.alpha8; params.pi2; params.rho2;...
%     params.rho3; params.alpha9; params.alpha10; params.alpha11; params.alpha12;...
%     params.c1; params.c2; params.c3; params.k; params.eta1; params.eta2;...
%     params.eta3; params.eta4; params.xi1; params.xi2; params.xi3; params.xi4;...
%     params.muCa; params.omega3; params.omega4];% params.ISparams]; 
% 
% 
% 
% save('allParams','-struct','params')

end

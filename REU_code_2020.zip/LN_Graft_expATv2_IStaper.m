
function dx = LN_Graft_expATv2_IStaper(t, x, params, treatOpts);

% CONDITIONS AND PARAMETERS WITH IS TREATMENT
% initialize IS equation to 0 in case of no treatment
% IS = 0;

% determine what treatment is required and set user's treatment options
treatments = treatOpts{1};
ATopts = treatOpts{2};
ISopts = treatOpts{3};
taperOpts = treatOpts{4};

if treatments(2) %CNI
    % inhibit Tcell activation in LN
    params.aE = params.aE*(1-x(17)/(params.IS_n + x(17)));
    params.aR = params.aR*(1-x(17)/(params.IS_n + x(17)));
    params.aH = params.aH*(1-x(17)/(params.IS_n + x(17)));
    
    % inhibit Tcell proliferation (pseudo activation) in Graft
    params.rEg = params.rEg*(1-x(17)/(params.IS_n+x(17)));
    params.rRg = params.rRg*(1-x(17)/(params.IS_n+x(17)));
    params.rHg = params.rHg*(1-x(17)/(params.IS_n+x(17)));
    
    params.rE = params.rE*(1-x(17)/(params.IS_n+x(17)));
    params.rR = params.rR*(1-x(17)/(params.IS_n+x(17)));
    params.rH = params.rH*(1-x(17)/(params.IS_n+x(17)));
    
    IS = params.k1-params.k2*x(17);
else
    IS=0;
end


% if treatments(2) || treatments(3)  %IS -- i.e., if CNI or mTOR
%     D0_IS = ISopts(1);
%     ISini = ISopts(1);
%
%     % parameter inhibition
%     if treatments(2)  %CNI
%         params.k1 = ISini*params.muIS_CNI;
%         IS = params.k1-params.muIS_CNI*x(17);
%
%
%         params.psiLN_CNI = 2.9e10;
%         params.psiG_CNI = 1.1e17;
%         params.psiLN_mTOR = 1e14;
%         params.psiG_mTOR = 1e14;
%         params.muIS_CNI = 1.7; % sourced
%         params.muIS_mTOR = 0.3; % sourced
%         params.hIS_CNI = 0.0007; % found from peak CNI @ 2 hrs
%         params.hIS_mTOR = 0.004; % found from peak mTOR @ 5 hrs
%
%
%
%         % tapering
%         if treatments(4)
%             startTaper = taperOpts(1);
%             lenTaper = taperOpts(2);
%
%             if t > startTaper && t <= startTaper + lenTaper
%                 IS = -ISini/lenTaper;
%             elseif t > startTaper + lenTaper
%                 ISini = 0;
%                 IS = 0;
%             end
%
%         end
%
%         %         %set h for dosing equation
%         h_IS = params.hIS_CNI;
%         muIS = params.muIS_CNI;
%
%         % inhibit Tcell activation in LN
%         params.aE = params.aE*(1-x(17)/(params.psiLN_CNI + x(17)));
%         params.aR = params.aR*(1-x(17)/(params.psiLN_CNI + x(17)));
%         params.aH = params.aH*(1-x(17)/(params.psiLN_CNI + x(17)));
%
%         % inhibit Tcell proliferation (pseudo activation) in Graft
%         params.rEg = params.rEg*(1-x(17)/(params.psiG_CNI+x(17)));
%         params.rRg = params.rRg*(1-x(17)/(params.psiG_CNI+x(17)));
%         params.rHg = params.rHg*(1-x(17)/(params.psiG_CNI+x(17)));
%     else  %mTOR
%         %         %set h for dosing eq
%         h_IS = params.hIS_mTOR;
%         muIS = params.muIS_mTOR;
%
%         %doseIS = D0_IS * muIS_mTOR;
%
%         params.k1 = ISini*params.muIS_mTOR;
%         IS = params.k1 - params.muIS_mTOR*x(17);
%
%         if treatments(4)
%             startTaper = taperOpts(1);
%             lenTaper = taperOpts(2);
%
%             if t > startTaper && t <= startTaper + lenTaper
%                 IS = -ISini/lenTaper;
%             elseif t > startTaper + lenTaper
%                 ISini = 0;
%                 IS = 0;
%             end
%
%         end
%         % inhibit Tcell proliferation in LN
%         params.rE = params.rE*(1-x(17)/(params.psiLN_mTOR+x(17)));
%         params.rR = params.rR*(1 - x(17)/(3*(params.psiLN_mTOR + x(17)))); % 1/3 inhibition for Treg
%         params.rH = params.rH*(1 - x(17)/(params.psiLN_mTOR + x(17)));
%
%         % inhibit Aimm -> Amat activation
%         params.ap1 = params.ap1*(1-x(17)/(params.psiG_mTOR + x(17)));
%     end
%
%     if length(ISopts) > 1 % bolus dose
%         doseLength_IS = ISopts(2);
%         startDay_IS = ISopts(3);
%         endDay_IS = startDay_IS + doseLength_IS - 1;
%         doseTime_IS = startDay_IS:endDay_IS;
%
%         doseIS = D0_IS*exp(-(doseTime_IS-t).^2./params.h_IS);
%         doseFun = sum(doseIS);
%     else % constant dose
%         doseFun = D0_IS*muIS; % constant dose
%     end
%
%     IS = -muIS*x(17) + doseFun;

% end



%%%% EQUATIONS -- NO AT %%%%
%LYMPH NODE EQUATIONS
ALN = params.eA*x(8) - params.muA*x(1);
TEnaive = params.muEN*(params.EffNaive_ini-x(2));
TELN = (params.aE*x(2)*x(1)*x(7))/((params.gamma1+x(1))*(params.alpha1 + ...
    x(5))) - params.muE*x(3) +(params.rE*x(3)*x(1))/(params.beta1+x(1))- ...
    params.eE*x(3);
TRnaive = params.muRN*(params.RegNaive_ini - x(4));
TRLN = (params.aR*x(4)*x(1))/(params.gamma2+x(1)) - params.muR*x(5) + ...
    (params.rR*x(5)*(x(3)+x(7)))/(params.alpha2+x(5))-params.eR*x(5);
% TRLN=0;
THnaive = params.muHN*(params.HelpNaive_ini-x(6));
THLN = params.aH*x(6)*x(1)/((params.gamma3 +x(1))*(params.alpha3+x(5)))+...
    params.rH*x(7)*x(1)/(params.gamma4+x(1))-params.muH*x(7)-params.eH*x(7);


%GRAFT EQUATIONS
Amat = params.ap1*(1-x(16)^2/(params.eta1^2+x(16)^2))*(x(9)*(x(15)+...
    params.zeta*x(13))/((params.alpha4+x(12)))) - params.muAmat*x(8) - ...
    params.eA*x(8);


Aimm = params.kcp*x(15)*x(14) - params.muAimm*(x(9)-...
    params.A0*x(14)/params.Graft_ini) - params.ap1*(1-x(16)^2/(params.eta1^2+...
    x(16)^2))*(x(9)*(x(15)+params.zeta*x(13))/((params.alpha4+x(12))))- ...
    params.ap2*(1-x(16)^2/(params.eta2^2+x(16)^2))*(x(9)*x(13)/...
    ((params.alpha5+x(12))));


Ainf = params.ap2*(1-x(16)^2/(params.eta2^2+x(16)^2))*(x(9)*x(13)/...
    ((params.alpha5+x(12))))-params.muAinf*x(10);


TEG = params.k*params.eE*x(3) - params.muE*x(11) + params.rEg*(1 - ...
    x(16)^2/(params.eta3^2 + x(16)^2))*x(11)*x(14)/(params.beta2+x(14));
TRG = params.k*params.eR*x(5) - params.muR*x(12) + params.rRg*x(12)*...
    (x(11)+x(13))/(params.alpha6+x(12));
THG = params.k*params.eH*x(7) - params.muH*x(13) + params.rHg*(1 - ...
    x(16)^2/(params.eta4^2 + x(16)^2))*x(13)*x(8)/(params.gamma5+x(8));
G = params.rG*x(14)*(1-x(14)/params.Gmax) - params.dinf*x(10)*x(14)/...
    (params.alpha7 + x(12)) - params.dE*x(11)*x(14)/(params.alpha8 + x(12));
Cp = params.rho1*x(8)/(params.alpha9+x(12))+params.rho2*x(11)/...
    (params.alpha10+x(12))+params.rho3*x(13)/(params.alpha11+x(12))+...
    params.rho4*x(10)/(params.alpha12+x(12))-params.mucp*x(15);
Ca = params.xi1*x(8)+params.xi2*x(12)+params.xi3*x(15)*x(14)+...
    params.xi4*x(10)-params.muCa*x(16);
% Ca=0;


%%%% ADDING AT %%%%
if treatments(1)
    % set dosing equations
    k=2;%10
    D0_exp = ATopts(1);
    doseLength = ATopts(2);
    fracG = ATopts(3);
    fracLN = ATopts(4);
    fracN = ATopts(5);
    startDay = ATopts(6);
    
    endDay = startDay + doseLength - 1;
    doseTime = startDay:endDay;
    
    
    pastDoses = doseTime(doseTime <= t);
    
    
    doseG = fracG*D0_exp*exp(-(t-pastDoses)*k);
    doseLN  = fracLN*D0_exp*exp(-(t-pastDoses)*k);
    doseN  = fracN*D0_exp*exp(-(t-pastDoses)*k);
    
    % add Treg dosing to existing equations
    TRG = TRG + sum(doseG);
    TRLN = TRLN + sum(doseLN);
    TRnaive = TRnaive + sum(doseN);
    
    
    
    
end




dx = [ALN;TEnaive;TELN;TRnaive;TRLN;THnaive;THLN;Amat;Aimm;Ainf;TEG;TRG;THG;G;Cp;Ca;IS];


end